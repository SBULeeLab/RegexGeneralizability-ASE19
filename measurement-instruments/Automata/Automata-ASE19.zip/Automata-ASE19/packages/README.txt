all nuget packages are installed in this folder
