# -*- coding: utf-8 -*-
# from scripts.extractor.java import *
# from scripts.extractor.js import *
# from scripts.extractor.php import *
# from scripts.extractor.python import *
# __all__ = ['java', 'js', 'php', 'python']
