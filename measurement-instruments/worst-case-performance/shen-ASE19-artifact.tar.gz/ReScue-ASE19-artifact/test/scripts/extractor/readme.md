# Regex Extractors
- These regex extractor are written in python, and try to extract regex by regex.
- They are not complete, but are efficient.

# TODO-LIST
- Extract regex by AST
