package cn.edu.nju.moon.redos.tester;

public class SlowFuzzBest extends TempTester {

	public static void main(String[] args) {
		slowfuzzBest(args);
	}

}
