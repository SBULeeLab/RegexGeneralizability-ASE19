package cn.edu.nju.moon.redos.gui;

import javax.swing.*;

public class GUI extends JFrame{
	public static void main(String[] args) {
		GUI gui = new GUI();
		gui.setVisible(true);
	}
	
	public GUI() {
		
	}
}
