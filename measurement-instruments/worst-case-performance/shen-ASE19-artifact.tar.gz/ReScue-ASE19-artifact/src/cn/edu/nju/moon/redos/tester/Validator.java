package cn.edu.nju.moon.redos.tester;

public class Validator extends TempTester{
	public static void main(String[] args) {
		validate(args);
	}
}
