java -cp utils/pumper/ PumperJava "$@"
