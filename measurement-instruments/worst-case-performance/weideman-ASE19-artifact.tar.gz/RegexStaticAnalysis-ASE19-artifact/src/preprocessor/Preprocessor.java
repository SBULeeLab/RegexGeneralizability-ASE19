package preprocessor;

public interface Preprocessor {
	
	public String applyRules(String regex);

}
