package util;

public final class Constants {

	public final static int MILLISECONDS_IN_SECOND = 1000;

	/* Do not instantiate */
	private Constants() {
	}
}
