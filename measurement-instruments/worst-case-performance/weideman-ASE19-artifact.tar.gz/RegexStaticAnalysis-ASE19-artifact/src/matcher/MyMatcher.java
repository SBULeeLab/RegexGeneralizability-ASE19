package matcher;

public interface MyMatcher {


	public boolean matches();

}
