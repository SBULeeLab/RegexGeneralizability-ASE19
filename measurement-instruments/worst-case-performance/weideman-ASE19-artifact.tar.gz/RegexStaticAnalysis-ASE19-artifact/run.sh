java -Xms2048m -cp './bin/:./lib/gson-2.8.2.jar' driver.Main "$@"
