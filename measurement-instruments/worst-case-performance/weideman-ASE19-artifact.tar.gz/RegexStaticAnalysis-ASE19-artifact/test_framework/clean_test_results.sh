#!/bin/bash
rm -r ./test_results/*
