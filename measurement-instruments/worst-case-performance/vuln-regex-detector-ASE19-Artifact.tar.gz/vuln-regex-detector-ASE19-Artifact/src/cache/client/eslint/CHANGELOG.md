# v1

## v1.0

### v1.0.4

Additions:
- Bump vuln-regex-detector version for configurable cache.
- Support environment variable control of server and cache configuration.

Contributors:
- [Jamie Davis](davisjam@vt.edu)

### v1.0.3

Additions:
- Update README with recommended usage and performance
- Bump vuln-regex-detector version

Contributors:
- [Jamie Davis](davisjam@vt.edu)

### v1.0.2

- Update README

Contributors:
- [Jamie Davis](davisjam@vt.edu)

### v1.0.1

- Update README

Contributors:
- [Jamie Davis](davisjam@vt.edu)

### v1.0.0

First release!

Contributors:
- [Jamie Davis](davisjam@vt.edu)
