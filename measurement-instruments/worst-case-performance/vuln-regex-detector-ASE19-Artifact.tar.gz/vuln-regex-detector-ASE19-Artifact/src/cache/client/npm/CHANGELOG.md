# v1

## v1.3

### v1.3.0

*Additions*

- Change config param to make the cache configurable. This is a breaking change.

Contributors:
- [Jamie Davis](davisjam@vt.edu)

## v1.2

### v1.2.0

*Additions*

- Add a persistent local cache. This is now the default.

Contributors:
- [Jamie Davis](davisjam@vt.edu)

## v1.1

### v1.1.1

*Additions*

- Update README

Contributors:
- [Jamie Davis](davisjam@vt.edu)

### v1.1.0

*Additions*

- Add a synchronous API for use in an eslint plugin.
- Add an in-memory cache in case the same regex is repeated during a Node process's lifetime.

Contributors:
- [Jamie Davis](davisjam@vt.edu)

## v1.0

### v1.0.1

*Additions*

- Misc. bugfixes
- Enhance test suites

Contributors:
- [Jamie Davis](davisjam@vt.edu)

### v1.0.0

First release!

Contributors:
- [Jamie Davis](davisjam@vt.edu)
