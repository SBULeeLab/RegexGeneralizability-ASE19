#!/usr/bin/env node

var re = /abc/;
'abc'.match(/def/);
new RegExp('aaa');
