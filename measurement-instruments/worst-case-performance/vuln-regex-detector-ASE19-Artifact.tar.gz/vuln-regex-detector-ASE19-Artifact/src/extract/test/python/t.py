#!/usr/bin/env python

import re
import re as RE

re.search('(?<=abc)def', 'foo')
RE.compile('(a+)+!$')
